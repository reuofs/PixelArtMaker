// Select color input
// Select size input
var table = document.getElementById('pixelCanvas');
var color = document.getElementById('colorPicker');
var sizePicker = document.getElementById('sizePicker');


var height = document.getElementById('inputHeight').value;
var width = document.getElementById('inputWidth').value;
makeGrid(height , width);

sizePicker.addEventListener('click', (event) => {

    event.preventDefault();

    table.firstElementChild.remove();
    var height = document.getElementById('inputHeight').value;
    var width = document.getElementById('inputWidth').value;
    makeGrid(height, width);
});
// When size is submitted by the user, call makeGrid()

function makeGrid(h,w) {

for (let i = 0; i < h; i++) {
    let row = table.insertRow(i);
    for (let j = 0; j < w; j++){
        let cell = row.insertCell(j);
        cell.addEventListener('click' , (event) => {
            console.log(event);
            cell.style.backgroundColor = color.value;

        });
    }
}

}
